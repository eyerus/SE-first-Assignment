1.Student registration form
	-One module in student registration app
	-It saves students info from the form to the database
	-It is based on EVENT-DRIVEN design pattern
	-It needs to run the nodeJS enviroment and MONGODB for the database
2. BMI calculator
	-A module that calculates body mass index of a person
	-It is based on MVC design pattern
	-It is java code.