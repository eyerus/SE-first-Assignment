var mongoose = require('mongoose');
var express = require('express');
var bodyParser = require('body-parser');
var assert = require('assert');
var path = require('path');

const studentModel = require('./models/student');

var mongoose = require('mongoose');



var url = 'mongodb://localhost:27017/MyDb';
mongoose.connect(url);

var db = mongoose.connection;

db.on('error',console.error.bind(console,'connection error'));
db.on('open',function(){
    console.log('connected');
});

var app = express();

app.use(bodyParser.json());

app.use(express.static('public'));

app.post('/register',function(req,res) {  
    var student1 = studentModel();
    student1.name =  req.body.name;
    student1.ID = req.body.ID;
    student1.age =  req.body.age;
    student1.department = req.body.department;
    student1.email =  req.body.email;
    student1.phone = req.body.phone;

    if( student1.name && student1.ID && student1.age && student1.department && student1.email && student1.phone){
      student1.save(function (err) {
      if (err) {
        res.send(err);
        res.send("Some error.couldnt register");
      } else {
         res.send("Not registered....please fill the form correctly!!!");
        //res.json({ sucess: true, message: "student registered successfully!!" });
      }
    });
    }else{
        res.send("Not registered....please fill the form correctly!!!");
        //res.json({ sucess: false, message: "info is not provided"});
    }
    
    
   
});

app.listen(3000);