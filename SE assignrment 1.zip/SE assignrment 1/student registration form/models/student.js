var mongoose = require('mongoose');
var assert = require('assert');
var Schema = mongoose.Schema;
var studentSchema = new Schema({
    name:{
        type:String,
        require: true,
        
    },
    ID:{
        type:String,
        require: true,
        unique: true
    },
    age:{
        type: Number,
        require: true
    },
    department:{
        type: String,
        require: true
    },
    email:{
        type: String,
        required: true,
    },
    phone:{
      type: String,
      require: true  
    }
    
});
// var adminSchema = new Schema({
//     name:{
//         type:String,
//         require: true,
//         unique: true
//     },
//     password:{
//         type: String,
//         require: true
//     }
    
// });
module.exports = mongoose.model('studentModel',studentSchema);
 