/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bmi;

/**
 *
 * @author User
 */
public class BMIModel{
	private double BMIResult;
	
	public void calculateBMI(double height,double weight){
		
		BMIResult = weight / (height*height);
	};
	
	public double getBMIResult(){
		 
		 return BMIResult;
	};
}
