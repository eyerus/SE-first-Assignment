/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bmi;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BMIController{
	private BMIView theView;
	private BMIModel theModel;
	
	public BMIController(BMIView theView, BMIModel theModel){
		this.theView = theView;
		this.theModel = theModel;
		
		this.theView.calculateBMIListener(new BMIListener());
		
	}
	
	class BMIListener implements ActionListener{
                
		public void actionPerformed(ActionEvent arg){
			double height = 0;
			double weight = 0;
			
			try{
				height = theView.getHeight2();
				weight = theView.getWeight();
                                
				
				theModel.calculateBMI(height,weight);
				
				theView.setBMIResult((int) theModel.getBMIResult());
			}
			catch(NumberFormatException ex){
				//theView.displayErrorMessage("enter both height and weight");
			}
		}

	}
}