/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bmi;

import java.awt.event.ActionListener;
import java.awt.GridLayout;
import javax.swing.*;

public class BMIView extends JFrame{
	private JLabel heightLabel = new JLabel("    height in meter");
	private JTextField height = new JTextField(10);
	private JLabel weightLabel = new JLabel("    weight in kg");
	private JTextField weight = new JTextField(10);
	
	private JButton calculateBMIButton = new JButton("calculate BMI");
	
	private JButton clear = new JButton("clear");
	
	private JLabel BMILabel = new JLabel("    BMI");
        private JLabel Label = new JLabel("");
	private JTextField BMIResult = new JTextField(10);
	
	
	//private JButton exit = new JButton("exit");
	
	BMIView(){
		
		JPanel BMIPanel = new JPanel();
                JPanel BMIPanel2 = new JPanel();
		
		GridLayout layout1 = new GridLayout(0,2,15,15);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500,250);
		
                BMIPanel.setLayout(layout1);
                
		BMIPanel.add(heightLabel);
		BMIPanel.add(height);
		BMIPanel.add(weightLabel);
		BMIPanel.add(weight);
		BMIPanel.add(calculateBMIButton);
		BMIPanel.add(Label);
		BMIPanel.add(BMILabel);
		BMIPanel.add(BMIResult);
                this.add(BMIPanel);
                
	};
	public double getHeight2(){
               
		return Double.parseDouble(height.getText());
	};
	public double getWeight(){
		return Double.parseDouble(weight.getText());
	}
	public double getBMI(){
		return Double.parseDouble(BMIResult.getText());
	}
	public void setBMIResult(int result){
		BMIResult.setText(Double.toString(result));
	}
	void calculateBMIListener(ActionListener listenerForBMIButton){
		calculateBMIButton.addActionListener(listenerForBMIButton);
	}
	
	
}
